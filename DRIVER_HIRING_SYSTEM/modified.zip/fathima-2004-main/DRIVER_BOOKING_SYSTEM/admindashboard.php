<?php
include("./auth/adminauth.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="admin.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <nav class="nanbar">
        <div class="navbar">
            <a class="hdng" href="">DRIVER BOOKING SYSTEM</a>
            <div class="link">
                 <a href="home.html">Home</a> 
                <a href="manageuser.php">Manage user</a>
                <a href="managestaff.php">Manage staff</a>
                <a href="displayfdbk.php">View feedback</a>
                <a href="viewbookings.php">Manage bookings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
        </div>
    </nav>
    <div class="doc">
        <h1 class="hg">Admin Dashboard</h1>
    </div>


</body>

</html>