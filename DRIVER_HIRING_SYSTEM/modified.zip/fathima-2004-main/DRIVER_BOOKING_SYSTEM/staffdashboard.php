<?php
include("./auth/staffauth.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="staffhome.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <nav class="nanbar">
        <div class="navbar">
            <a class="hdng"  href="">DRIVER BOOKING SYSTEM</a>
            <div class="link">
                <a href="managebookings.php">Manage bookings</a>
                <a href="driverprofile.php">Edit Profile</a>
                <a href="displayfdbk.php">View feedback</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
        </div>
    </nav>

      <div class="doc">
        <h1 class="hg">staff Dashboard</h1>
      </div>

</body>

</html>