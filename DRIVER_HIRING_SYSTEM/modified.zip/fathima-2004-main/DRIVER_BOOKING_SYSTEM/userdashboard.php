<?php
include("./auth/userauth.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="userhome.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <nav class="nanbar">
        <div class="navbar">
            <a class="hdng"  href="">DRIVER BOOKING SYSTEM</a>
            <div class="link">
                <a href="mybookings.php">My bookings</a>
                <a href="viewdriver.php">View Drivers</a>
                <a href="userprofile.php">Profile</a>
                <a href="feedback.php">Feedback</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
        </div>
    </nav>
      <div class="doc">
        <h1 class="hg">User Dashboard</h1>
      </div>

</body>

</html>